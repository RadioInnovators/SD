The following files were generated for 'CLarmFilter' in directory
C:\Users\tibbs2010\Dropbox\SD\serial_buffers\ipcore_dir\

Opens the IP Customization GUI:
   Allows the user to customize or recustomize the IP instance.

   * CLarmFilter.mif

XCO file generator:
   Generate an XCO file for compatibility with legacy flows.

   * CLarmFilter.xco

Creates an implementation netlist:
   Creates an implementation netlist for the IP.

   * CLarmFilter.ngc
   * CLarmFilter.v
   * CLarmFilter.veo
   * CLarmFilterCOEFF_auto0_0.mif
   * CLarmFilterfilt_decode_rom.mif

Creates an HDL instantiation template:
   Creates an HDL instantiation template for the IP.

   * CLarmFilter.veo

IP Symbol Generator:
   Generate an IP symbol based on the current project options'.

   * CLarmFilter.asy
   * CLarmFilter.mif

SYM file generator:
   Generate a SYM file for compatibility with legacy flows

   * CLarmFilter.sym

Generate ISE metadata:
   Create a metadata file for use when including this core in ISE designs

   * CLarmFilter_xmdf.tcl

Generate ISE subproject:
   Create an ISE subproject for use when including this core in ISE designs

   * CLarmFilter.gise
   * CLarmFilter.xise
   * _xmsgs/pn_parser.xmsgs

Deliver Readme:
   Readme file for the IP.

   * CLarmFilter_readme.txt

Generate FLIST file:
   Text file listing all of the output files produced when a customized core was
   generated in the CORE Generator.

   * CLarmFilter_flist.txt

Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

