The following files were generated for 'armFilter' in directory
C:\Users\tibbs2010\Documents\SD\trunk\user_sandbox\Brian\Verilog\CostasLoopEvalADCDAC\ipcore_dir\

Opens the IP Customization GUI:
   Allows the user to customize or recustomize the IP instance.

   * armFilter.mif

XCO file generator:
   Generate an XCO file for compatibility with legacy flows.

   * armFilter.xco

Creates an implementation netlist:
   Creates an implementation netlist for the IP.

   * armFilter.ngc
   * armFilter.v
   * armFilter.veo
   * armFilterCOEFF_auto0_0.mif
   * armFilterfilt_decode_rom.mif

Creates an HDL instantiation template:
   Creates an HDL instantiation template for the IP.

   * armFilter.veo

IP Symbol Generator:
   Generate an IP symbol based on the current project options'.

   * armFilter.asy
   * armFilter.mif

SYM file generator:
   Generate a SYM file for compatibility with legacy flows

   * armFilter.sym

Generate ISE metadata:
   Create a metadata file for use when including this core in ISE designs

   * armFilter_xmdf.tcl

Generate ISE subproject:
   Create an ISE subproject for use when including this core in ISE designs

   * _xmsgs/pn_parser.xmsgs
   * armFilter.gise
   * armFilter.xise

Deliver Readme:
   Readme file for the IP.

   * armFilter_readme.txt

Generate FLIST file:
   Text file listing all of the output files produced when a customized core was
   generated in the CORE Generator.

   * armFilter_flist.txt

Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

