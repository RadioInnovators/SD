The following files were generated for 'sine_elg' in directory
C:\Users\tibbs2010\Documents\SD\trunk\user_sandbox\Brian\Verilog\DemodulatorEvalADCDAC\ipcore_dir\

Generate XCO file:
   CORE Generator input file containing the parameters used to generate a core.

   * sine_elg.xco

Generate Implementation Netlist:
   Binary Xilinx implementation netlist files containing the information
   required to implement the module in a Xilinx (R) FPGA.

   * sine_elg.ngc

Obfuscate Netlist Generator:
   Please see the core data sheet.

   * sine_elg.ngc

Generate Instantiation Templates:
   Template files containing code that can be used as a model for instantiating
   a CORE Generator module in an HDL design.

   * sine_elg.veo

RTL Simulation Model Generator:
   Please see the core data sheet.

   * sine_elg.v

All Documents Generator:
   Please see the core data sheet.

   * sine_elg/doc/dds_compiler_v4_0_vinfo.html
   * sine_elg/doc/dds_ds558.pdf

Deliver IP Symbol:
   Graphical symbol information file. Used by the ISE tools and some third party
   tools to create a symbol representing the core.

   * sine_elg.asy

SYM file generator:
   Generate a SYM file for compatibility with legacy flows

   * sine_elg.sym

Generate XMDF file:
   ISE Project Navigator interface file. ISE uses this file to determine how the
   files output by CORE Generator for the core can be integrated into your ISE
   project.

   * sine_elg_xmdf.tcl

Generate ISE project file:
   ISE Project Navigator support files. These are generated files and should not
   be edited directly.

   * _xmsgs/pn_parser.xmsgs
   * sine_elg.gise
   * sine_elg.xise

Deliver Readme:
   Readme file for the IP.

   * sine_elg_readme.txt

Generate FLIST file:
   Text file listing all of the output files produced when a customized core was
   generated in the CORE Generator.

   * sine_elg_flist.txt

Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

